import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class MyCollection<T extends Comparable> implements Collection<T> {
    List<T> myList = new ArrayList<T>();

    public void addElement(T element) {
        int tmp = myList.size();
        for (int i = 0; i < myList.size(); i++) {
            if (element.compareTo(myList.get(i)) < 1) {
                myList.add(i,element);
                break;
            }
        }

        if(tmp == myList.size()){
            myList.add(element);
        }
    }

    @Override
    public int size() {
        return this.myList.size();
    }

    @Override
    public boolean isEmpty() {
        if(this.size()==0){
            return true;
        }
        return false;
    }

    @Override
    public boolean contains(Object o) {
        for(int i=0;i<this.size();i++){
            if (this.myList.get(i).equals(o)){
                return true;
            }
        }
        return false;
    }

    @Override
    public Iterator<T> iterator() {
        return this.myList.iterator();
    }

    @Override
    public Object[] toArray() {
        Object[] tab = new Object[this.size()];
        for (int i=0; i<this.size();i++){
            tab[i]=this.myList.get(i);
        }
        return tab;
    }

    @Override
    public <T1> T1[] toArray(T1[] t1s) {
        T1[] tab = (T1[])new Object[this.size()];
        for (int i=0; i<this.size();i++){
            tab[i]=(T1) this.myList.get(i);
        }
        return tab;
    }

    @Override
    public boolean add(T t) {
        int start_size = this.size();
        this.addElement(t);
        if (start_size +1 == this.size()) {
            return true;
        }
        return false;
    }

    @Override
    public boolean remove(Object o) {
        for (int i=0; i<this.size(); i++){
            if (this.myList.get(i).equals(o)){
                this.myList.remove(i);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean containsAll(Collection<?> collection) {
        for (Object obj: collection){
            if (!(this.myList.contains(obj))){
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean addAll(Collection<? extends T> collection) {
        int start_size = this.size();
        for (Object obj : collection){
            this.addElement((T) obj);
        }
        if (start_size + collection.size() == this.size()){
            return true;
        }
        return false;
    }

    @Override
    public boolean removeAll(Collection<?> collection) {
        int counter= 0;
        int start_size = this.size();
        for (Object obj : collection){
            if ((this.contains(obj))){
                this.remove(obj);
                counter++;
            }
        }
        if (this.size() == start_size - counter){
            return true;
        }
        return false;
    }

    @Override
    public boolean retainAll(Collection<?> collection) {
        int counter = 0;
        int startSize = this.size();
        MyCollection newCollection= new MyCollection<T>();
        for (Object obj: collection){
            if (this.contains(obj)){
                newCollection.add((T) obj);
                counter++;
            }
        }
        this.myList = newCollection.myList;
        if (newCollection.size() == startSize - counter){
            return true;
        }
        return false;
    }

    @Override
    public void clear() {
        this.myList = new ArrayList<T>();
    }
}
