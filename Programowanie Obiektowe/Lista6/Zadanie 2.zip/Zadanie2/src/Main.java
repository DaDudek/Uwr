public class Main {
    // korzyści z tego płynące są takie, że wiele metod przyjmuje obiekt typu Collection<E>
    // więc automatycznie dostajemy możliwość przekazywania naszej kolekcji do wszystkich tych metod

    public static void main(String[] args) {
        MyCollection emptyCollection = new MyCollection<Integer>();
        MyCollection collection = new MyCollection<Integer>();
        Integer x = 5;
        Integer y = 7;
        Integer z = 4;
        Integer a = 6;
        Integer b = 7;
        Integer c = 3;
        Integer d = 9;

        collection.addElement(x);
        System.out.println(collection.myList);
        collection.addElement(y);
        System.out.println(collection.myList);
        collection.addElement(z);
        System.out.println(collection.myList);
        collection.addElement(a);
        System.out.println(collection.myList);
        collection.addElement(b);
        System.out.println(collection.myList);
        collection.addElement(c);
        System.out.println(collection.myList);
        collection.addElement(d);
        System.out.println(collection.myList);

        // size test
        System.out.println("Size test");
        System.out.println(collection.size());
        System.out.println(emptyCollection.size());

        //empty test
        System.out.println("empty test");
        System.out.println(collection.isEmpty());
        System.out.println(emptyCollection.isEmpty());

        //contains test
        System.out.println("contains test");
        Integer xd = 3;
        Integer notInCollection = 3265457 ;
        System.out.println(collection.contains(xd));
        System.out.println(emptyCollection.contains(xd));
        System.out.println(collection.contains(notInCollection));
        System.out.println(emptyCollection.contains(notInCollection));

        // add test
        System.out.println("add test");
        System.out.println(collection.myList);
        collection.add(xd);
        System.out.println(collection.myList);

        //remove test
        System.out.println("remove test");
        System.out.println(collection.myList);
        emptyCollection.remove(xd);
        collection.remove(xd);
        System.out.println(collection.myList);
        collection.remove(notInCollection);
        System.out.println(collection.myList);

        //containsAll test

        MyCollection testCollection = new MyCollection<Integer>();
        testCollection.add(xd);
        MyCollection otherTestCollection = new MyCollection<Integer>();
        otherTestCollection.add(xd);
        otherTestCollection.add(notInCollection);
        System.out.println("containsAll test");
        System.out.println(collection.containsAll(testCollection));
        System.out.println(collection.containsAll(otherTestCollection));
        System.out.println(emptyCollection.containsAll(testCollection));
        System.out.println(emptyCollection.containsAll(otherTestCollection));


        //addAll test
        System.out.println("addAll test");
        System.out.println(collection.myList);
        System.out.println(otherTestCollection.myList);
        collection.addAll(otherTestCollection);
        System.out.println(collection.myList);

        //removeAll test
        System.out.println("removeAll test");
        System.out.println(collection.myList);
        System.out.println(otherTestCollection.myList);
        collection.removeAll(otherTestCollection);
        System.out.println(collection.myList);


        //retainAll test
        System.out.println("retainAll test");
        System.out.println(collection.myList);
        System.out.println(otherTestCollection.myList);
        collection.retainAll(otherTestCollection);
        System.out.println(collection.myList);


        //clear test
        System.out.println("clear test");
        System.out.println(collection.myList);
        collection.clear();
        System.out.println(collection.myList);
    }

}
